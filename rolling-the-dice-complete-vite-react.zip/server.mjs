import { createServer } from 'node:http'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

const port = Number(process.env.PORT ?? 8787)
const adminPassword = process.env.ADMIN_PASSWORD ?? '27372'
const dataDir = resolve('data')
const dataFile = join(dataDir, 'rolling-the-dice.json')

const seedData = {
  settings: {
    title: 'Rolling the Dice',
    tagline: 'College football dynasty articles, rankings, recruiting, and playoff coverage.',
    breaking: 'Dynasty board is live: track rankings, recruiting news, playoff watch, and game-day stories.',
    accent: '#c43c2f',
  },
  nextArticleId: 4,
  nextTeamId: 9,
  teams: ['Georgia', 'Ohio State', 'Texas', 'Oregon', 'Alabama', 'Michigan', 'Notre Dame', 'Penn State'].map(
    (name, index) => ({ id: index + 1, name, votes: 8 - index }),
  ),
  articles: [
    {
      id: 1,
      title: 'Dynasty Board: Programs Built For November',
      category: 'CFB',
      summary: 'The strongest college football teams have stable lines, calm quarterbacks, and defenses that finish.',
      content:
        'A dynasty starts with repeatable habits. The best college football programs do not rely on one lucky Saturday. They stack recruiting, development, play calling, and fourth-quarter discipline until winning becomes part of the structure.\n\nThis season, the playoff race will be shaped by teams that can survive ugly road games, protect the football, and keep their identity when the crowd gets loud.',
      author: 'Rolling the Dice Staff',
      imageUrl: '',
      videoUrl: '',
      isFeatured: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 2,
      title: 'Recruiting Notebook: The Visits That Matter Most',
      category: 'Recruiting',
      summary: 'Late visits can swing a class when a player sees the depth chart clearly.',
      content:
        'Recruiting is not just about stars. It is about fit, timing, trust, and whether a staff can show a player a believable path to the field. The best visits answer football questions and family questions at the same time.',
      author: 'Rolling the Dice Staff',
      imageUrl: '',
      videoUrl: '',
      isFeatured: false,
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: 3,
      title: 'Film Room: Why Pre-Snap Motion Changes Everything',
      category: 'Film Room',
      summary: 'Motion forces defenses to communicate before the ball is snapped.',
      content:
        'Pre-snap motion gives the offense answers. It can reveal man coverage, stress linebackers, and create better angles for the run game. When used well, it makes the defense declare its plan early.',
      author: 'Rolling the Dice Staff',
      imageUrl: '',
      videoUrl: '',
      isFeatured: false,
      createdAt: new Date(Date.now() - 172800000).toISOString(),
    },
  ],
}

function readStore() {
  if (!existsSync(dataDir)) {
    mkdirSync(dataDir, { recursive: true })
  }

  if (!existsSync(dataFile)) {
    writeFileSync(dataFile, JSON.stringify(seedData, null, 2))
  }

  return JSON.parse(readFileSync(dataFile, 'utf8'))
}

function writeStore(store) {
  writeFileSync(dataFile, JSON.stringify(store, null, 2))
}

function snapshot(store = readStore()) {
  return {
    settings: store.settings,
    articles: [...store.articles].sort(
      (a, b) => Number(b.isFeatured) - Number(a.isFeatured) || new Date(b.createdAt) - new Date(a.createdAt),
    ),
    teams: [...store.teams].sort((a, b) => b.votes - a.votes || a.name.localeCompare(b.name)),
  }
}

async function readBody(request) {
  const chunks = []

  for await (const chunk of request) {
    chunks.push(chunk)
  }

  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}
}

function json(response, status, payload) {
  response.writeHead(status, {
    'content-type': 'application/json',
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
    'access-control-allow-headers': 'content-type',
  })
  response.end(JSON.stringify(payload))
}

function summarize(text) {
  return String(text).trim().replace(/\s+/g, ' ').slice(0, 190)
}

createServer(async (request, response) => {
  try {
    if (request.method === 'OPTIONS') {
      return json(response, 200, {})
    }

    if (request.url !== '/api/network') {
      return json(response, 404, { message: 'Not found.' })
    }

    if (request.method === 'GET') {
      return json(response, 200, snapshot())
    }

    const body = await readBody(request)
    const store = readStore()

    if (body.action === 'vote') {
      const team = store.teams.find((item) => item.id === body.teamId)
      if (!team) return json(response, 400, { message: 'Team not found.' })
      team.votes += 1
      writeStore(store)
      return json(response, 200, snapshot(store))
    }

    if (body.pin !== adminPassword) {
      return json(response, 401, { message: 'Admin access is required.' })
    }

    if (body.action === 'verify') {
      return json(response, 200, { ok: true })
    }

    if (body.action === 'createArticle') {
      const article = body.article ?? {}
      if (!article.title?.trim() || !article.category?.trim() || !article.content?.trim()) {
        return json(response, 400, { message: 'Title, category, and article body are required.' })
      }

      store.articles.push({
        id: store.nextArticleId++,
        title: article.title.trim(),
        category: article.category.trim(),
        summary: article.summary?.trim() || summarize(article.content),
        content: article.content.trim(),
        author: article.author?.trim() || 'Rolling the Dice Staff',
        imageUrl: article.imageUrl?.trim() || '',
        videoUrl: article.videoUrl?.trim() || '',
        isFeatured: Boolean(article.isFeatured),
        createdAt: new Date().toISOString(),
      })
      writeStore(store)
      return json(response, 201, snapshot(store))
    }

    if (body.action === 'addTeam') {
      const name = String(body.name ?? '').trim()
      if (!name) return json(response, 400, { message: 'Team name is required.' })

      if (!store.teams.some((team) => team.name.toLowerCase() === name.toLowerCase())) {
        store.teams.push({ id: store.nextTeamId++, name, votes: 0 })
      }

      writeStore(store)
      return json(response, 200, snapshot(store))
    }

    if (body.action === 'updateSettings') {
      store.settings = { ...store.settings, ...body.settings }
      writeStore(store)
      return json(response, 200, snapshot(store))
    }

    return json(response, 400, { message: 'Unsupported action.' })
  } catch (error) {
    console.error(error)
    return json(response, 500, { message: 'Server error.' })
  }
}).listen(port, () => {
  console.log(`Rolling the Dice backend running at http://localhost:${port}`)
})
