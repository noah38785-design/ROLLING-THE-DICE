import { useEffect, useMemo, useState } from 'react'
import {
  Bookmark,
  CalendarDays,
  ChevronsUp,
  Clipboard,
  Dice5,
  Eye,
  Flame,
  ListChecks,
  LogOut,
  Megaphone,
  Newspaper,
  Palette,
  Plus,
  Radio,
  Search,
  ShieldCheck,
  Star,
  Target,
  Trophy,
  Users,
} from 'lucide-react'

const adminSessionKey = 'rolling-dice-admin'
const savedArticlesKey = 'rolling-dice-saved'
const draftKey = 'rolling-dice-draft'

const categories = [
  'CFB',
  'Recruiting',
  'Game Recaps',
  'Opinion',
  'Player Spotlights',
  'Film Room',
  'Predictions',
  'Transfer Portal',
  'Conference News',
]

const gameDay = [
  { title: 'Georgia vs Alabama', tag: 'Saturday 7:30 PM', text: 'Prime-time trenches and playoff energy.' },
  { title: 'Ohio State vs Michigan', tag: 'Saturday Noon', text: 'Rivalry pressure with every possession magnified.' },
  { title: 'Texas vs Oklahoma', tag: 'Saturday 3:30 PM', text: 'Neutral-site momentum swings and quarterback tests.' },
  { title: 'Oregon vs USC', tag: 'Friday 8:00 PM', text: 'Speed, space, and explosive play alerts.' },
]

const playoffBoard = ['Georgia', 'Ohio State', 'Texas', 'Oregon', 'Alabama', 'Michigan']

const watchlist = [
  'Quarterback battles that are still undecided',
  'Transfer portal linemen changing conference races',
  'Freshmen who can flip special teams',
  'Red-zone defenses that bend without breaking',
  'Coaches handling late-game clock pressure',
]

const emptyArticle = {
  title: '',
  summary: '',
  content: '',
  category: 'CFB',
  imageUrl: '',
  videoUrl: '',
  author: 'Rolling the Dice Staff',
  isFeatured: false,
}

export default function App() {
  const [snapshot, setSnapshot] = useState(null)
  const [view, setView] = useState('home')
  const [category, setCategory] = useState('All')
  const [query, setQuery] = useState('')
  const [selectedArticle, setSelectedArticle] = useState(null)
  const [articleForm, setArticleForm] = useState(emptyArticle)
  const [settingsForm, setSettingsForm] = useState(null)
  const [pin, setPin] = useState('')
  const [adminPin, setAdminPin] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const [newTeam, setNewTeam] = useState('')
  const [savedArticleIds, setSavedArticleIds] = useState([])
  const [message, setMessage] = useState('')

  useEffect(() => {
    loadSnapshot()

    const session = localStorage.getItem(adminSessionKey)
    const saved = localStorage.getItem(savedArticlesKey)
    const draft = localStorage.getItem(draftKey)

    if (session) {
      const parsed = JSON.parse(session)
      setAdminPin(parsed.pin)
      setIsAdmin(true)
    }

    if (saved) {
      setSavedArticleIds(JSON.parse(saved))
    }

    if (draft) {
      setArticleForm({ ...emptyArticle, ...JSON.parse(draft) })
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(draftKey, JSON.stringify(articleForm))
  }, [articleForm])

  useEffect(() => {
    if (snapshot?.settings) {
      setSettingsForm(snapshot.settings)
    }
  }, [snapshot])

  async function loadSnapshot() {
    const response = await fetch('/api/network')
    setSnapshot(await response.json())
  }

  async function postAction(payload, successMessage) {
    setMessage('')
    const response = await fetch('/api/network', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    })
    const data = await response.json()

    if (!response.ok) {
      setMessage(data.message || 'Something went wrong.')
      return null
    }

    if (data.articles) {
      setSnapshot(data)
    }

    if (successMessage) {
      setMessage(successMessage)
    }

    return data
  }

  const articles = snapshot?.articles ?? []
  const teams = snapshot?.teams ?? []
  const settings = settingsForm ?? snapshot?.settings ?? {}
  const allCategories = useMemo(
    () => Array.from(new Set([...categories, ...articles.map((article) => article.category)])),
    [articles],
  )

  const filteredArticles = useMemo(() => {
    const search = query.trim().toLowerCase()
    return articles.filter((article) => {
      const categoryMatch = category === 'All' || article.category === category
      const searchMatch =
        !search || `${article.title} ${article.summary} ${article.content} ${article.category}`.toLowerCase().includes(search)
      return categoryMatch && searchMatch
    })
  }, [articles, category, query])

  const savedArticles = articles.filter((article) => savedArticleIds.includes(article.id))
  const totalVotes = teams.reduce((sum, team) => sum + team.votes, 0)

  function openHome(nextCategory = 'All') {
    setView('home')
    setCategory(nextCategory)
    setSelectedArticle(null)
  }

  function openView(nextView) {
    setView(nextView)
    setSelectedArticle(null)
  }

  function toggleSaved(articleId) {
    const nextSaved = savedArticleIds.includes(articleId)
      ? savedArticleIds.filter((id) => id !== articleId)
      : [...savedArticleIds, articleId]

    setSavedArticleIds(nextSaved)
    localStorage.setItem(savedArticlesKey, JSON.stringify(nextSaved))
  }

  async function copyArticle(article) {
    await navigator.clipboard.writeText(`${article.title} - Rolling the Dice`)
    setMessage('Article title copied.')
  }

  async function login(event) {
    event.preventDefault()
    const result = await postAction({ action: 'verify', pin }, 'Admin studio unlocked.')

    if (result?.ok) {
      setAdminPin(pin)
      setIsAdmin(true)
      localStorage.setItem(adminSessionKey, JSON.stringify({ pin }))
      setPin('')
    }
  }

  async function publishArticle(event) {
    event.preventDefault()
    const result = await postAction({ action: 'createArticle', pin: adminPin, article: articleForm }, 'Article published.')

    if (result) {
      localStorage.removeItem(draftKey)
      setArticleForm({ ...emptyArticle, category: articleForm.category })
      openHome(articleForm.category)
    }
  }

  function logout() {
    setIsAdmin(false)
    setAdminPin('')
    localStorage.removeItem(adminSessionKey)
    setMessage('Admin studio locked.')
  }

  return (
    <div className="app" style={{ '--accent': settings.accent ?? '#c43c2f' }}>
      <header className="site-header">
        <div className="brand-mark">
          <Dice5 />
        </div>
        <div>
          <p className="kicker">Mr. Dice Project Edition</p>
          <h1>{settings.title ?? 'Rolling the Dice'}</h1>
          <p className="tagline">{settings.tagline}</p>
        </div>
        <button className="ghost-button" type="button" onClick={() => openView('admin')}>
          <ShieldCheck size={18} />
          {isAdmin ? 'Studio Open' : 'Studio'}
        </button>
      </header>

      <div className="breaking-strip">
        <Megaphone size={18} />
        <span>{settings.breaking}</span>
      </div>

      <main>
        <section className="hero">
          <div>
            <p className="kicker">Dynasty Desk</p>
            <h2>College football articles, rankings, recruiting, and playoff race coverage.</h2>
            <p>Built for fast article drops, fan-voted rankings, game-day storylines, and a modern sports-news feel.</p>
          </div>
          <div className="scoreboard">
            <Stat value={articles.length} label="stories" />
            <Stat value={teams.length} label="teams" />
            <Stat value={totalVotes} label="votes" />
            <Stat value={articles.filter((article) => article.isFeatured).length} label="featured" />
          </div>
        </section>

        <section className="quick-panels">
          <QuickButton icon={<Target />} label="Playoff Board" detail={`${playoffBoard.length} teams`} onClick={() => openView('playoff')} />
          <QuickButton icon={<CalendarDays />} label="Game Day" detail={`${gameDay.length} matchups`} onClick={() => openView('gameday')} />
          <QuickButton icon={<ListChecks />} label="Watchlist" detail={`${watchlist.length} keys`} onClick={() => openView('watchlist')} />
          <QuickButton icon={<Users />} label="Recruiting" detail="commit watch" onClick={() => openHome('Recruiting')} />
        </section>

        <nav className="nav-tabs">
          <Tab active={view === 'home' && category === 'All'} icon={<Newspaper />} label="Home" onClick={() => openHome()} />
          {allCategories.map((item) => (
            <Tab key={item} active={view === 'home' && category === item} icon={<Flame />} label={item} onClick={() => openHome(item)} />
          ))}
          <Tab active={view === 'gameday'} icon={<Radio />} label="Game Day" onClick={() => openView('gameday')} />
          <Tab active={view === 'playoff'} icon={<Target />} label="Playoff" onClick={() => openView('playoff')} />
          <Tab active={view === 'watchlist'} icon={<Star />} label="Watchlist" onClick={() => openView('watchlist')} />
          <Tab active={view === 'rankings'} icon={<Trophy />} label="Rankings" onClick={() => openView('rankings')} />
          <Tab active={view === 'admin'} icon={<ShieldCheck />} label="Admin" onClick={() => openView('admin')} />
        </nav>

        {message ? <p className="message">{message}</p> : null}

        {view === 'home' ? (
          <section className="content-grid">
            <div className="panel">
              <div className="toolbar">
                <div>
                  <p className="kicker">Latest Articles</p>
                  <h2>{category === 'All' ? 'The Full Board' : category}</h2>
                </div>
                <label className="search-box">
                  <Search size={18} />
                  <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search coverage" />
                </label>
              </div>

              {selectedArticle ? (
                <ArticleReader
                  article={selectedArticle}
                  isSaved={savedArticleIds.includes(selectedArticle.id)}
                  onBack={() => setSelectedArticle(null)}
                  onCopy={copyArticle}
                  onSave={toggleSaved}
                />
              ) : (
                <ArticleList articles={filteredArticles} savedArticleIds={savedArticleIds} onOpen={setSelectedArticle} onSave={toggleSaved} />
              )}
            </div>

            <aside className="side-stack">
              <RankingsRail teams={teams.slice(0, 5)} onVote={(teamId) => postAction({ action: 'vote', teamId })} />
              <SavedRail articles={savedArticles} onOpen={setSelectedArticle} />
            </aside>
          </section>
        ) : null}

        {view === 'gameday' ? <FeaturePage title="Saturday Game Day Board" icon={<Radio />} items={gameDay} /> : null}
        {view === 'playoff' ? <PlayoffPage /> : null}
        {view === 'watchlist' ? <WatchlistPage /> : null}

        {view === 'rankings' ? (
          <section className="panel">
            <div className="toolbar">
              <div>
                <p className="kicker">Dynasty Rankings</p>
                <h2>Fan-Controlled Power Board</h2>
              </div>
              <Trophy size={36} />
            </div>
            <div className="card-grid">
              {teams.map((team, index) => (
                <RankingCard key={team.id} team={team} index={index} onVote={() => postAction({ action: 'vote', teamId: team.id })} />
              ))}
            </div>
          </section>
        ) : null}

        {view === 'admin' ? (
          <AdminStudio
            isAdmin={isAdmin}
            pin={pin}
            setPin={setPin}
            login={login}
            logout={logout}
            articleForm={articleForm}
            setArticleForm={setArticleForm}
            publishArticle={publishArticle}
            settings={settings}
            setSettingsForm={setSettingsForm}
            saveSettings={() => postAction({ action: 'updateSettings', pin: adminPin, settings }, 'Settings saved.')}
            newTeam={newTeam}
            setNewTeam={setNewTeam}
            addTeam={() => postAction({ action: 'addTeam', pin: adminPin, name: newTeam }, 'Team added.').then(() => setNewTeam(''))}
            teams={teams}
          />
        ) : null}
      </main>
    </div>
  )
}

function Stat({ value, label }) {
  return (
    <div>
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  )
}

function QuickButton({ icon, label, detail, onClick }) {
  return (
    <button type="button" onClick={onClick}>
      {icon}
      <span>{label}</span>
      <strong>{detail}</strong>
    </button>
  )
}

function Tab({ active, icon, label, onClick }) {
  return (
    <button className={active ? 'tab active' : 'tab'} type="button" onClick={onClick}>
      {icon}
      {label}
    </button>
  )
}

function ArticleList({ articles, savedArticleIds, onOpen, onSave }) {
  if (!articles.length) {
    return <div className="empty-state">No articles yet. Open Admin and publish a new story.</div>
  }

  const [lead, ...rest] = articles

  return (
    <div className="article-stack">
      <ArticleCard article={lead} isLead isSaved={savedArticleIds.includes(lead.id)} onOpen={onOpen} onSave={onSave} />
      <div className="card-grid two">
        {rest.map((article) => (
          <ArticleCard
            key={article.id}
            article={article}
            isSaved={savedArticleIds.includes(article.id)}
            onOpen={onOpen}
            onSave={onSave}
          />
        ))}
      </div>
    </div>
  )
}

function ArticleCard({ article, isLead = false, isSaved, onOpen, onSave }) {
  return (
    <article className={isLead ? 'article-card lead-card' : 'article-card'}>
      <ArticleMedia article={article} />
      <div>
        <span className="article-tag">{article.category}</span>
        <h3>{article.title}</h3>
        <p>{article.summary}</p>
        <small>
          {formatDate(article.createdAt)} · {readingTime(article.content)}
        </small>
        <div className="button-row">
          <button type="button" onClick={() => onOpen(article)}>
            <Eye size={17} />
            Read
          </button>
          <button type="button" onClick={() => onSave(article.id)}>
            <Bookmark size={17} />
            {isSaved ? 'Saved' : 'Save'}
          </button>
        </div>
      </div>
    </article>
  )
}

function ArticleReader({ article, isSaved, onBack, onCopy, onSave }) {
  return (
    <article className="reader">
      <div className="button-row">
        <button type="button" onClick={onBack}>
          <Eye size={17} />
          Back
        </button>
        <button type="button" onClick={() => onSave(article.id)}>
          <Bookmark size={17} />
          {isSaved ? 'Saved' : 'Save'}
        </button>
        <button type="button" onClick={() => onCopy(article)}>
          <Clipboard size={17} />
          Copy
        </button>
      </div>
      <ArticleMedia article={article} />
      <span className="article-tag">{article.category}</span>
      <h2>{article.title}</h2>
      <small>
        {formatDate(article.createdAt)} by {article.author} · {readingTime(article.content)}
      </small>
      {article.content.split(/\n+/).map((paragraph) => (
        <p key={paragraph}>{paragraph}</p>
      ))}
    </article>
  )
}

function ArticleMedia({ article }) {
  if (article.imageUrl) {
    return <img className="article-media" src={article.imageUrl} alt="" />
  }

  return (
    <div className="article-media generated">
      <Dice5 size={44} />
      <b>{article.category}</b>
    </div>
  )
}

function RankingsRail({ teams, onVote }) {
  return (
    <section className="rail">
      <p className="kicker">Top Fan Board</p>
      <h2>Rankings</h2>
      {teams.map((team, index) => (
        <div className="rank-row" key={team.id}>
          <strong>{index + 1}</strong>
          <span>
            {team.name}
            <small>{team.votes} votes</small>
          </span>
          <button type="button" onClick={() => onVote(team.id)}>
            <ChevronsUp size={18} />
          </button>
        </div>
      ))}
    </section>
  )
}

function SavedRail({ articles, onOpen }) {
  return (
    <section className="rail">
      <p className="kicker">Reading List</p>
      <h2>Saved</h2>
      {articles.length ? (
        articles.map((article) => (
          <button className="saved-button" key={article.id} type="button" onClick={() => onOpen(article)}>
            <Bookmark size={17} />
            {article.title}
          </button>
        ))
      ) : (
        <p>Save articles to build your own reading list.</p>
      )}
    </section>
  )
}

function FeaturePage({ title, icon, items }) {
  return (
    <section className="panel">
      <div className="toolbar">
        <div>
          <p className="kicker">College Football</p>
          <h2>{title}</h2>
        </div>
        {icon}
      </div>
      <div className="card-grid">
        {items.map((item) => (
          <article className="feature-card" key={item.title}>
            <strong>{item.tag}</strong>
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </article>
        ))}
      </div>
    </section>
  )
}

function PlayoffPage() {
  return (
    <section className="panel">
      <div className="toolbar">
        <div>
          <p className="kicker">Playoff Pulse</p>
          <h2>College Football Playoff Board</h2>
        </div>
        <Target size={36} />
      </div>
      <div className="card-grid">
        {playoffBoard.map((team, index) => (
          <article className="feature-card" key={team}>
            <strong>#{index + 1}</strong>
            <h3>{team}</h3>
            <p>Contender profile trending upward with dynasty-level expectations.</p>
          </article>
        ))}
      </div>
    </section>
  )
}

function WatchlistPage() {
  return (
    <section className="panel">
      <div className="toolbar">
        <div>
          <p className="kicker">Watchlist</p>
          <h2>What To Track Next Saturday</h2>
        </div>
        <ListChecks size={36} />
      </div>
      <div className="watchlist">
        {watchlist.map((item, index) => (
          <article key={item}>
            <strong>{index + 1}</strong>
            <div>
              <h3>{item}</h3>
              <p>Use this angle for article ideas, recap notes, and rankings updates.</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

function RankingCard({ team, index, onVote }) {
  return (
    <article className="feature-card">
      <strong>#{index + 1}</strong>
      <h3>{team.name}</h3>
      <p>{team.votes} fan votes</p>
      <button type="button" onClick={onVote}>
        <ChevronsUp size={17} />
        Vote
      </button>
    </article>
  )
}

function AdminStudio({
  isAdmin,
  pin,
  setPin,
  login,
  logout,
  articleForm,
  setArticleForm,
  publishArticle,
  settings,
  setSettingsForm,
  saveSettings,
  newTeam,
  setNewTeam,
  addTeam,
  teams,
}) {
  if (!isAdmin) {
    return (
      <section className="panel admin-login">
        <div>
          <p className="kicker">Admin Studio</p>
          <h2>Unlock Publishing Controls</h2>
        </div>
        <form onSubmit={login}>
          <input value={pin} onChange={(event) => setPin(event.target.value)} type="password" placeholder="Password: 27372" />
          <button type="submit">
            <ShieldCheck size={17} />
            Login
          </button>
        </form>
      </section>
    )
  }

  return (
    <section className="panel">
      <div className="toolbar">
        <div>
          <p className="kicker">Admin Studio</p>
          <h2>Publish And Customize</h2>
        </div>
        <button type="button" onClick={logout}>
          <LogOut size={17} />
          Logout
        </button>
      </div>

      <div className="admin-grid">
        <form onSubmit={publishArticle} className="form-panel">
          <h3>Post Article</h3>
          <p>Drafts autosave in this browser.</p>
          <input value={articleForm.title} onChange={(event) => setArticleForm({ ...articleForm, title: event.target.value })} placeholder="Title" />
          <input
            value={articleForm.category}
            onChange={(event) => setArticleForm({ ...articleForm, category: event.target.value })}
            placeholder="Category"
            list="category-list"
          />
          <datalist id="category-list">
            {categories.map((item) => (
              <option key={item} value={item} />
            ))}
          </datalist>
          <textarea
            value={articleForm.summary}
            onChange={(event) => setArticleForm({ ...articleForm, summary: event.target.value })}
            placeholder="Summary"
            rows={3}
          />
          <textarea
            value={articleForm.content}
            onChange={(event) => setArticleForm({ ...articleForm, content: event.target.value })}
            placeholder="Full article"
            rows={8}
          />
          <input
            value={articleForm.imageUrl}
            onChange={(event) => setArticleForm({ ...articleForm, imageUrl: event.target.value })}
            placeholder="Image URL"
          />
          <label className="check-row">
            <input
              checked={articleForm.isFeatured}
              onChange={(event) => setArticleForm({ ...articleForm, isFeatured: event.target.checked })}
              type="checkbox"
            />
            Feature this story
          </label>
          <button type="submit">
            <Plus size={17} />
            Post
          </button>
        </form>

        <div className="admin-side">
          <div className="form-panel preview-box">
            <h3>Live Preview</h3>
            <span className="article-tag">{articleForm.category}</span>
            <h4>{articleForm.title || 'Your headline appears here'}</h4>
            <p>{articleForm.summary || articleForm.content.slice(0, 180) || 'Your summary appears here.'}</p>
            <small>{readingTime(articleForm.content || 'preview')}</small>
          </div>

          <form
            className="form-panel"
            onSubmit={(event) => {
              event.preventDefault()
              saveSettings()
            }}
          >
            <h3>Site Settings</h3>
            <input value={settings.title ?? ''} onChange={(event) => setSettingsForm({ ...settings, title: event.target.value })} />
            <input value={settings.tagline ?? ''} onChange={(event) => setSettingsForm({ ...settings, tagline: event.target.value })} />
            <textarea value={settings.breaking ?? ''} onChange={(event) => setSettingsForm({ ...settings, breaking: event.target.value })} rows={3} />
            <input value={settings.accent ?? '#c43c2f'} onChange={(event) => setSettingsForm({ ...settings, accent: event.target.value })} type="color" />
            <button type="submit">
              <Palette size={17} />
              Save Look
            </button>
          </form>

          <form
            className="form-panel"
            onSubmit={(event) => {
              event.preventDefault()
              addTeam()
            }}
          >
            <h3>Add Ranking Team</h3>
            <input value={newTeam} onChange={(event) => setNewTeam(event.target.value)} placeholder="Team name" />
            <button type="submit">
              <Trophy size={17} />
              Add Team
            </button>
          </form>

          <div className="chips">
            {teams.map((team, index) => (
              <span key={team.id}>
                #{index + 1} {team.name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function formatDate(value) {
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value))
}

function readingTime(text) {
  const words = String(text).trim().split(/\s+/).filter(Boolean).length
  return `${Math.max(1, Math.ceil(words / 220))} min read`
}
