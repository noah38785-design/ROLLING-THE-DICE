# Rolling the Dice

A complete Vite + React college football dynasty website.

## Features

- College football article homepage
- Navigation between Home, Rankings, Game Day, Playoff, Watchlist, Recruiting, Film Room, Transfer Portal, and Admin
- Admin password: `27372`
- Admin stays signed in using browser storage
- Admin can post unlimited articles
- Admin can add unlimited teams to the rankings board
- Custom Node backend, no Netlify
- Persistent data stored in `data/rolling-the-dice.json`

## Run In Codespaces

Install dependencies:

```bash
npm install
```

Start the backend:

```bash
npm run backend
```

Open a second terminal and start the Vite app:

```bash
npm run dev
```

Open the forwarded port for `3000`.
